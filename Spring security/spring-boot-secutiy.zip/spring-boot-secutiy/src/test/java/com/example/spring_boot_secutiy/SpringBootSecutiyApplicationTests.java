package com.example.spring_boot_secutiy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecutiyApplicationTests {

	@Test
	void contextLoads() {
	}

}
