package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeignClientMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeignClientMicroServiceApplication.class, args);
	}

}
